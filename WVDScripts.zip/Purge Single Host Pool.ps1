﻿#####
#
#   Purge single WVD Hostpool and dependencies
#
#   Note: Does not purge any Azure VMs, dependencies, or AD Objects. Only RDInfra assets (e.g. WVD session hosts, AppGroups)
#
#  **** WARNING: THIS IS A DESTRUCTIVE SCRIPT, USE CAUTION AS THE ACTIONS CANNOT BE UNDONE ****
#####

# Import RDInfra PowerShell Module
Install-Module -name Microsoft.RDInfra.RDPowerShell
Import-Module -name Microsoft.RDInfra.RDPowerShell

# Authenticate with WVD Broker
Add-RdsAccount -DeploymentUrl "https://rdbroker.wvd.microsoft.com"

# Define Variables

    # WVD Tenant Name
    $wvd_tenant_name = 'Your WVD Tenant Name'

    # WVD Hostpool Name
    $wvd_hostpool_name = 'Your WVD Hostpool Name'

Function CleanHostPool ($HostPool, $Tenant){
    
    $error.clear()

    try { 
        $ErrorActionPreference = 'Stop'
        $return = Get-RdsHostPool -TenantName $Tenant -Name $HostPool 
    }catch { 
        "Hostpool does not exist" 
    }
    if (!$error) {
        $ErrorActionPreference = "Continue"
        # Get all Session Hosts for $HostPool, remove session hosts
            
        $SessionHosts = (Get-RdsSessionHost -TenantName $Tenant -HostPoolName $HostPool)

        foreach ($SessionHost in $SessionHosts){
            #Delete Session Hosts

            Write-Host "Deleting Session Host: " $SessionHost.SessionHostName
            Remove-RdsSessionhost -TenantName $Tenant -HostPoolName $HostPool -Name $SessionHost.SessionHostName -Force

        }

        $AppGroups = (Get-RdsAppGroup -TenantName $Tenant -HostPoolName $HostPool)

        foreach ($AppGroup in $AppGroups) {
            
            $Apps = (Get-RdsRemoteApp -TenantName $Tenant -HostPoolName $HostPool $AppGroup.AppGroupName)

            #Delete Remote Apps
            foreach($App in $Apps){

                Write-Host "Deleting App: " $App.RemoteAppName
                Remove-RdsRemoteApp -TenantName $Tenant -HostPoolName $HostPool -AppGroupName $AppGroup.AppGroupName -Name $App.RemoteAppName

            }
            #Delete App Group
            Write-Host "Deleting AppGroup: " $AppGroup.AppGroupName

            Remove-RdsAppGroup  -TenantName $Tenant -HostPoolName $HostPool $AppGroup.AppGroupName
        }

        #Delete Hostpool

        Write-Host "Deleting Hostpool: " $HostPool
        Remove-RdsHostPool -TenantName $Tenant -HostPoolName $HostPool

        Get-RdsHostPool -TenantName $Tenant

        Write-Host "Done"
    }
   
}

#Run function to cleanup Hostpool resources

CleanHostPool -hostPool $wvd_hostpool_name -tenant $wvd_tenant_name
