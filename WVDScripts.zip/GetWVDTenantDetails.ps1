﻿# To use this script, first login to WVD using: Add-RdsAccount –DeploymentUrl “https://rdbroker.wvd.microsoft.com”
# Then, run Get-RdsTenant
    # this will tell you which WVD Tenants you can query
# Next, run the entire PS1 or hit F5 to run the entire script
# Finally, issue the command: Get-WVD NameofTenant

Function Get-WVD {
    param( $TenantName )
    
    Write-Host "|------------------------------|"
    Write-Host "| Get-RdsTenant                |"
    Write-Host "|------------------------------|"
    Get-RdsTenant -Name $TenantName
    # Pull tenant by name
    Get-RdsTenant -Name $TenantName | ForEach-Object {    
        Write-Host "|------------------------------|"
        Write-Host "| Get-RdsHostPool              |"
        Write-Host "|------------------------------|"
        Get-RdsHostPool -TenantName $TenantName
        # Pull a list of  host pools for the tenant
        Get-RdsHostPool -TenantName $TenantName | ForEach-Object {
            $HostPoolName = $_.HostPoolName
            # Pull a list of session hosts for the host pool 
            Write-Host "|------------------------------|"
            Write-Host "| Get-RdsSessionHost           |"
            Write-Host "|------------------------------|"
            Get-RdsSessionHost -TenantName $TenantName -HostPoolName $HostPoolName 
            
            Write-Host "|------------------------------|"
            Write-Host "| Get-RdsAppGroup              |"
            Write-Host "|------------------------------|"
            Get-RdsAppGroup -TenantName $TenantName -HostPoolName $HostPoolName
            # Pull the list of app groups
            Get-RdsAppGroup -TenantName $TenantName -HostPoolName $HostPoolName | ForEach-Object {
                $AppGroupName = $_.AppGroupName
                If ($AppGroupName -ne "Desktop Application Group") {
                    Write-Host "|------------------------------|"
                    Write-Host "| Get-RdsRemoteApp             |"
                    Write-Host "|------------------------------|"
                    
                    # Pull a list of published apps
                    Get-RdsRemoteApp -TenantName $TenantName -HostPoolName $HostPoolName -AppGroupName $AppGroupName
                }
            }
        }
    }
}

#Get-WVD <YOUR_WVD_TENANT_NAME>
