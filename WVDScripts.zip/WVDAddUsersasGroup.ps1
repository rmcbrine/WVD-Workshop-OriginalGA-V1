#Created by Manuel Garriga - mgarriga@microsoft.com
#For internal Microsoft use only, not customer-ready

Echo "Installing Remote Desktop PS Module . . ."
Install-Module -name Microsoft.RDInfra.RDPowerShell
Echo "Importing Remote Desktop PS Module . . ."
Import-Module -name Microsoft.RDinfra.rdpowershell
Echo "Let's authenticate to your RDS Tenant Group:"

add-rdsaccount -DeploymentUrl "https://rdbroker.wvd.microsoft.com"

<#
Uncomment the following lines if you want to use parameters specified in this PS script
#>
# Set name of AAD group you'll be using:
$GroupName="AzureHourUsers"
# Provide WVD Tenant Name:
$TenantName="azurehour"
# Provide HostPool Name
$HostPoolName="GPU"
# Provide App Group Name
$AppGroupName="Desktop Application Group"
# Add or Remove access?
$Action="Add"

<#
Uncomment the following lines if you want to run the PS script interactivly and get prompted for parameters while running the PS Script
#>

#$GroupName=Read-Host -Prompt "Set name of AAD group to modify permissions for"
#$TenantName=Read-Host -Prompt "Provide WVD Tenant Name"
#$HostPoolName=Read-Host -Prompt "Provide HostPool Name"
#$AppGroupName=Read-Host -Prompt "Provide App Group Name"
#$Action=Read-Host -Prompt "Type Add to add users to the App Group $AppGroupName, Remove to remove users from the App Group $AppGroupName"


<#
Code block that steps through AAD group (Nested groups not supported), adding or removing group members from RDSAppGroupUser
#>

Echo "Let's connect to Azure AD with a user that has read access to the group members"
Connect-AzureAD

$GroupObjectID=Get-AzureADGroup -Searchstring $GroupName
$GroupMembers= Get-AzureADGroupMember -objectid $GroupObjectID.ObjectID 


ECHO Operating on group $GroupObjectID
ECHO TOP 10 members are $GroupMembers.UserprincipalName |Select -first 10 


Write-Output "OK, we're going to modify users in group $GroupName against WVD Tenant $TenantName, Host Pool $HostPoolName, App Group $AppGroupName"



If ($Action -eq "add") {
Echo "The following users will be ADDED to AppGroup $AppGroupName :"
ECHO $GroupMembers.UserPrincipalName
ForEach ($member in $GroupMembers.UserPrincipalName) {
echo "Adding $member to $AppGroupName"
Add-RdsAppGroupUser -TenantName $TenantName -HostPoolName $HostPoolName -AppGroupName $AppGroupName -UserPrincipalName $member}
$RDSAppGroupUsersList=get-rdsappgroupuser -TenantName $tenantname -HostPoolName $hostpoolname -AppGroupName $AppGroupName
echo "Current users authorized for $AppGroupName are:"
echo $RDSAppGroupUsersList.UserPrincipalName
}

If ($Action -eq "remove") {
Echo "The following users will be REMOVED from AppGroup $AppGroupName :"
ECHO $GroupMembers.UserPrincipalName
ForEach ($member in $GroupMembers.UserPrincipalName) {
echo "Removing $member from $AppGroupName"
Remove-RdsAppGroupUser -TenantName $TenantName -HostPoolName $HostPoolName -AppGroupName $AppGroupName -UserPrincipalName $member}
$RDSAppGroupUsersList=get-rdsappgroupuser -TenantName $tenantname -HostPoolName $hostpoolname -AppGroupName $AppGroupName
echo "Current users authorized for $AppGroupName are:"
echo $RDSAppGroupUsersList.UserPrincipalName
}
